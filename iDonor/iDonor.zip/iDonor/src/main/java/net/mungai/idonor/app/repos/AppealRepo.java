package net.mungai.idonor.app.repos;

import net.mungai.idonor.app.models.DonationAppeal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface AppealRepo extends JpaRepository<DonationAppeal, Long> {

    @Query
    public List<DonationAppeal> findByApprovedTrue();

    @Query
    public List<DonationAppeal> findByApprovedFalse();

    @Query("Select u.requiredBloodType from DonationAppeal u")
    public List<DonationAppeal> checkBloodType();

    @Modifying
    @Transactional
    @Query("update DonationAppeal u set u.approved =:approved where u.id =:id")
    void updateAppeal(@Param(value = "id") Long id, @Param(value = "approved") boolean approved);

    @Modifying
    @Transactional
    @Query("UPDATE DonationAppeal u set u.approved = true where u.id =:id")
    void approveAppeal(@Param("id") Long id);

    @Modifying
    @Transactional
    @Query("update DonationAppeal u set u.approved = false  where u.id =:id")
    void rejectAppeal(@Param("id") Long id);

}
