package net.mungai.idonor.donor.repos;

import net.mungai.idonor.donor.models.Donor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface DonorRepo extends JpaRepository<Donor, Long> {

    @Query("select  u from Donor u where u.email = :email")
    public Donor getDonorByEmail(@Param("email") String email);


    @Query("SELECT d from Donor d join d.bloodType b where b.name like %?1%")
    public List<Donor> search(String keyword);

    @Query("Select d from Donor d join d.address a where a.county  like %?1%" +
            "or a.subCounty like %?1%" +
            "or a.ward like %?1%")
    public List<Donor> searchByAddress(String keyword);

    public Donor findDonorByAddress_CountyAndAddress_SubCountyAndAddress_Ward(String address_county, String address_subCounty, String address_ward);

    @Modifying
    @Transactional
    @Query("UPDATE Donor u set u.enabled = true where u.id =:id")
    void enableDonor(@Param("id") Long id);

    @Modifying
    @Transactional
    @Query("UPDATE Donor u set u.enabled = false where u.id =:id")
    void disableDonor(@Param("id") Long id);

}
