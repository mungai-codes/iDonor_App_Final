package net.mungai.idonor.app.twilio;

public interface SmsSender  {

    void sendSms(SmsRequest smsRequest);
}
