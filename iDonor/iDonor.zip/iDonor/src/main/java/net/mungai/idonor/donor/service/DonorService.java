package net.mungai.idonor.donor.service;


import net.mungai.idonor.app.models.Role;
import net.mungai.idonor.app.repos.RoleRepo;
import net.mungai.idonor.donor.models.Donor;
import net.mungai.idonor.donor.repos.DonorRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DonorService{

    @Autowired
    private DonorRepo donorRepo;
    @Autowired
    private RoleRepo roleRepo;

    public List<Donor> listAll(String keyword) {
        if( keyword != null){
            return donorRepo.search(keyword);
        }
        return donorRepo.findAll();
    }

    public List<Donor> addressSearch(String keyword){
        if(keyword != null){
            return donorRepo.searchByAddress(keyword);
        }
        System.err.println("address" + keyword + " not found!?");
        return donorRepo.findAll();
    }

    public void saveWithDefaultUserRole(Donor donor){
        Role donorsRole = roleRepo.findByName("user");
        donor.addRole(donorsRole);
        donorRepo.save(donor);
    }

    public Donor find(Long id) {
        return donorRepo.findById(id).get();
    }

    public void delete(Long id) {
        donorRepo.deleteById(id);
    }

    public Donor getByEmail(String email){
        return donorRepo.getDonorByEmail(email);
    }

    public void enableDonor(Long id){
        donorRepo.enableDonor(id);
    }

    public void disableDonor(Long id){
        donorRepo.disableDonor(id);
    }

}
