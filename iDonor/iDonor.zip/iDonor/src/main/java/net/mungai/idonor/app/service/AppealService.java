package net.mungai.idonor.app.service;

import net.mungai.idonor.app.models.DonationAppeal;
import net.mungai.idonor.app.repos.AppealRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppealService {

    @Autowired
    private AppealRepo appealRepo;

    public List<DonationAppeal> existingAppeals(){
       return appealRepo.findAll();
    }

    public List<DonationAppeal> approvedAppeal(){
        return appealRepo.findByApprovedTrue();
    }

    public List<DonationAppeal> unApprovedAppeal(){
        return appealRepo.findByApprovedFalse();
    }

    public void saveAppeal(DonationAppeal appeal){
        appealRepo.save(appeal);
    }

    public void saveApprovedAppeal(Long id, boolean approved){
        appealRepo.updateAppeal(id, approved);
    }

    public void approveAppeal(Long id){
        appealRepo.approveAppeal(id);
    }

    public void rejectAppeal(Long id){
        appealRepo.rejectAppeal(id);
    }

    public DonationAppeal get(Long id) {
        return appealRepo.getById(id);
    }
}
