package net.mungai.idonor.app.controllers;

import net.mungai.idonor.app.models.BloodType;
import net.mungai.idonor.app.repos.BloodTypeRepo;
import net.mungai.idonor.donor.models.Address;
import net.mungai.idonor.donor.models.Donor;
import net.mungai.idonor.donor.service.AddressService;
import net.mungai.idonor.donor.service.DonorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
public class AppController {


    @Autowired
    private DonorService donorService;
    @Autowired
    private AddressService addressService;
    @Autowired
    private BloodTypeRepo bloodTypeRepo;


    @RequestMapping("/")
    public String homePage(Model model, @Param("keyword") String keyword){
        List<Donor> someDonors = donorService.listAll(keyword);
        List<Donor> donorAddress =donorService.addressSearch(keyword);
        model.addAttribute("donorList",someDonors);
        model.addAttribute("addressSearch",donorAddress);
        model.addAttribute("keyword",keyword);
        return "index";
    }

    @RequestMapping("/registration")
    public String registrationForm(Model model){
        Address address =new Address();
        Donor donor = new Donor();
        List<BloodType> listBloodTypes =bloodTypeRepo.findAll();
        model.addAttribute("address",address);
        model.addAttribute("donor",donor);
        model.addAttribute("listBloodTypes",listBloodTypes);

        return "registration_form";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveDonor(@ModelAttribute Address address, @ModelAttribute Donor donor, @RequestParam("image") MultipartFile multipartFile) throws IOException {
        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        donor.setProfilePic(fileName);
        address.setDonor(donor);
        donorService.saveWithDefaultUserRole(donor);
        addressService.save(address);

        return "redirect:/";
    }

    @GetMapping("/bloodtypes")
    public String listBloodTypes(Model model){
        List<BloodType> listBloodTypes =bloodTypeRepo.findAll();
        model.addAttribute("listBloodTypes",listBloodTypes);
        return "bloodtypes";

    }

    @GetMapping("/createBloodType")
    public String addBloodType(Model model){
        model.addAttribute("bloodType", new BloodType());

        return "addBloodType";
    }

    @RequestMapping(value = "/bloodtypes/save")
    public String addBloodType(BloodType bloodType){
        bloodTypeRepo.save(bloodType);
        return "redirect:/bloodtypes";
    }

    @RequestMapping("/administrator")
    public String administrator(Model model , @Param("keyword") String keyword){
        List<Donor> listOfDonors = donorService.listAll(keyword);
        model.addAttribute("listOfDonors",listOfDonors);
        model.addAttribute("keyword",keyword);
        return "administrators_page";
    }

    @GetMapping("/home")
    public String home(){
        return "home";
    }

    @RequestMapping("/donor/enable/{id}")
    public String enableDonor(@PathVariable("id") Long id){
        donorService.enableDonor(id);
        return "redirect:/";
    }

    @RequestMapping("/donor/disable/{id}")
    public String disableDonor(@PathVariable("id") Long id){
        donorService.disableDonor(id);
        return "redirect:/";
    }

    @RequestMapping("/homepage")
    public String testHomepage(){
        return "homepage";
    }

}
