package net.mungai.idonor.app.models;

import javax.persistence.*;


@Entity
@Table(name = "appeal_details")
public class DonationAppeal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String recipientName;
    private Integer recipientAge;
    private String requiredBloodType;

    @OneToOne(mappedBy = "appeal", cascade = CascadeType.ALL)
    @PrimaryKeyJoinColumn
    private RecipientAddress recipientAddress;
    @Column(name = "isApproved",nullable = false)
    private boolean approved;
    private boolean relevance;

    public DonationAppeal(){

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    public Integer getRecipientAge() {
        return recipientAge;
    }

    public void setRecipientAge(Integer recipientAge) {
        this.recipientAge = recipientAge;
    }

    public String getRequiredBloodType() {
        return requiredBloodType;
    }

    public void setRequiredBloodType(String requiredBloodType) {
        this.requiredBloodType = requiredBloodType;
    }

    public RecipientAddress getRecipientAddress() {
        return recipientAddress;
    }

    public void setRecipientAddress(RecipientAddress recipientAddress) {
        this.recipientAddress = recipientAddress;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public boolean isRelevance() {
        return relevance;
    }

    public void setRelevance(boolean relevance) {
        this.relevance = relevance;
    }
}
