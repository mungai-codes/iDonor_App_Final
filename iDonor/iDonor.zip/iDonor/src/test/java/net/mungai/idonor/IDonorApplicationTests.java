package net.mungai.idonor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IDonorApplicationTests {

    @Test
    void contextLoads() {
    }

}
